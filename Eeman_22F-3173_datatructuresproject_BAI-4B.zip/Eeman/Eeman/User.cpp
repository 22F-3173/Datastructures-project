#include "User.h"
#include "Repository.h"

User::User(std::string _username, std::string _password) : username(_username), password(_password) {}

std::string User::getUsername() const {
    return username;
}

std::string User::getPassword() const {
    return password;
}

void User::addFollower(User* follower) {
    followers.push_back(follower);
}

void User::removeFollower(User* follower) {
    for (auto it = followers.begin(); it != followers.end(); ++it) {
        if (*it == follower) {
            followers.erase(it);
            break;
        }
    }
}

const std::vector<User*>& User::getFollowers() const {
    return followers;
}

void User::createRepository(std::string repoName, bool isPublic) {
    repositories.push_back(new Repository(repoName, isPublic, this));
}

void User::deleteRepository(std::string repoName) {
    for (auto it = repositories.begin(); it != repositories.end(); ++it) {
        if ((*it)->getName() == repoName) {
            delete* it;
            repositories.erase(it);
            break;
        }
    }
}

const std::vector<Repository*>& User::getRepositories() const {
    return repositories;
}