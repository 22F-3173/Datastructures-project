#include "File.h"

File::File(std::string _name, std::string _content) : name(_name), content(_content) {}

std::string File::getName() const {
    return name;
}

std::string File::getContent() const {
    return content;
}

FileNode::FileNode(File* _file) ; file(_file) {}

File* FileNode::getFile() const {
    return file;
}

const std::vector<FileNode*>& FileNode::getChildren() const {
    return children;
}

void FileNode::addChild(FileNode* child) {
    children.push_back(child);
}