#include <iostream>
#include <string>
#include <vector>
#include "Repository.h"
#include "User.h"

using namespace std;

int main() {
    vector<User*> users;

    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    users.push_back(new User(username, password));
    User* loggedInUser = users.front();
    cout << "Logged in as: " << loggedInUser->getUsername() << endl;

    char createRepoChoice;
    cout << "Create a repository? (yes/no): ";
    cin >> createRepoChoice;
    if (createRepoChoice == 'y' || createRepoChoice == 'Y') {
        string repoName;
        char visibilityChoice;
        bool isPublic;

        cout << "Enter repository name: ";
        cin >> repoName;
        cout << "Is the repository public? (yes/no): ";
        cin >> visibilityChoice;
        isPublic = (visibilityChoice == 'y' || visibilityChoice == 'Y');

        loggedInUser->createRepository(repoName, isPublic);
        cout << "Repository created: " << repoName << endl;

        // Adding files to the repository
        Repository* repo = loggedInUser->getRepositories().front();
        if (repo) {
            // Structure 1
            File* file1 = new File("file1.txt", "This is the content of file 1.");
            repo->addFile(file1, "folder1/");
            File* file2 = new File("file2.txt", "This is the content of file 2.");
            repo->addFile(file2, "folder1/");
            // Structure 2
            File* file3 = new File("file3.txt", "This is the content of file 3.");
            repo->addFile(file3, "folder2/");
            // Structure 3
            File* file4 = new File("file4.txt", "This is the content of file 4.");
            repo->addFile(file4, "folder3/");
            File* file5 = new File("file5.txt", "This is the content of file 5.");
            repo->addFile(file5, "folder3/subfolder1/");
            File* file6 = new File("file6.txt", "This is the content of file 6.");
            repo->addFile(file6, "folder3/subfolder2/");
            cout << "Files added to the repository." << endl;
        }
        else {
            cout << "Repository not found." << endl;
        }
    }

    // Cleaning up memory
    for (auto& user : users) {
        delete user;
    }

    return 0;
}