#ifndef REPOSITORY_H
#define REPOSITORY_H

#include <vector>
#include "File.h"
#include "Commit.h"

class User;

class Repository {
private:
    std::string name;
    bool isPublic;
    User* owner;
    std::vector<Commit*> commits;
    FileNode* root; // Root of the file tree

public:
    Repository(std::string _name, bool _isPublic, User* _owner);
    std::string getName() const;
    bool getVisibility() const;
    User* getOwner() const;
    void addCommit(Commit* commit);
    const std::vector<Commit*>& getCommits() const;
    void addFile(File* file, const std::string& path);
    File* getFile(const std::string& path);

private:
    std::vector<std::string> splitPath(const std::string& path);
    FileNode* findChildNode(FileNode* parentNode, const std::string& name);
    FileNode* getNodeByPath(const std::string& path);
};

#endif // REPOSITORY_H