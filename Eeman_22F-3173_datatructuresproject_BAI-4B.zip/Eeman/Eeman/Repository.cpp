#include "Repository.h"
#include "User.h"

Repository::Repository(std::string _name, bool _isPublic, User* _owner)
    : name(_name), isPublic(_isPublic), owner(_owner), root(nullptr) {}

std::string Repository::getName() const {
    return name;
}

bool Repository::getVisibility() const {
    return isPublic;
}

User* Repository::getOwner() const {
    return owner;
}

void Repository::addCommit(Commit* commit) {
    commits.push_back(commit);
}

const std::vector<Commit*>& Repository::getCommits() const {
    return commits;
}

void Repository::addFile(File* file, const std::string& path) {
    if (!root) {
        root = new FileNode(nullptr); // Root node is empty
    }
    FileNode* currentNode = root;
    std::vector<std::string> directories = splitPath(path);
    for (const auto& dir : directories) {
        FileNode* childNode = findChildNode(currentNode, dir);
        if (!childNode) {
            File* placeholder = new File(dir, ""); // 
            childNode = new FileNode(placeholder);
            currentNode->addChild(childNode);

        }
        currentNode = childNode;
    }
    currentNode->addChild(new FileNode(file));
}

File* Repository::getFile(const std::string& path) {
    FileNode* node = getNodeByPath(path);
    if (node && node->getFile()) {
        return node->getFile();
    }
    return nullptr;
}

std::vector<std::string> Repository::splitPath(const std::string& path) {
    std::vector<std::string> directories;
    std::string directory;
    for (char c : path) {
        if (c == '/') {
            if (!directory.empty()) {
                directories.push_back(directory);
                directory.clear();
            }
        }
        else {
            directory += c;
        }
    }
    if (!directory.empty()) {
        directories.push_back(directory);
    }
    return directories;
}

FileNode* Repository::findChildNode(FileNode* parentNode, const std::string& name) {
    for (FileNode* child : parentNode->getChildren()) {
        if (child->getFile()->getName() == name) {
            return child;
        }
    }
    return nullptr;
}

FileNode* Repository::getNodeByPath(const std::string& path) {
    std::vector<std::string> directories = splitPath(path);
    FileNode* currentNode = root;
    for (const auto& dir : directories) {
        currentNode = findChildNode(currentNode, dir);
        if (!currentNode) {
            return nullptr;
        }
    }
    return currentNode;
}
